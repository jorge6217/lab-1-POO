import java.util.Random;

public class Perro {
	private int estadoAnimo;
	private int umbral;
	public Random rand;
	
    public int numeroEstadoAnimo() {
    	int min_val = -5;
        int max_val = 5;
        Random rand = new Random();
        int randomNum = min_val + rand.nextInt((max_val - min_val) + 1);
        return randomNum;
    }
    
    public int numeroUmbral() {
    	int min_val = -20;
        int max_val = 0;
        Random rand = new Random();
        int randomNum = min_val + rand.nextInt((max_val - min_val) + 1);
        return randomNum;
    }
	
	public Perro() {
		this.estadoAnimo = numeroEstadoAnimo();
		this.umbral = numeroUmbral();
	}

	public int getEstadoAnimo() {
		return estadoAnimo;
	}

	public void setEstadoAnimo(int estadoAnimo) {
		this.estadoAnimo = estadoAnimo;
	}

	public int getUmbral() {
		return umbral;
	}

	public void setUmbral(int umbral) {
		this.umbral = umbral;
	}
	
	//REVISAR MAÑANA
	public int psican(Persona p) {
		this.estadoAnimo = (int) ((1.0 / p.getConfiabilidad()) * (rand.nextFloat() - 0.5) * 10 + this.estadoAnimo);
		if(p.isPoseeGalleta()) {
			p.darGalleta();
			this.estadoAnimo += (1.0/p.getConfiabilidad()) * (rand.nextInt(2));
		}
		return this.estadoAnimo;
	}
	
	public void morder() {
		System.out.println("Estoy asustando porque me mordiò el perro.");
	}
	
	public void ladrar() {
		System.out.println("Me alejè del perro porque me estaba ladrando.");
	}
	
	public void moverCola() {
		System.out.println("Estoy acariciando al perro porque le agradè.");
	}
	
	
	

	
	
	
	
	
}
