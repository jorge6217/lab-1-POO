import java.util.Random;

public class Persona {
	private int confiabilidad;
	private boolean poseeGalleta;
	
	int min = 0;
	int max = 10;
	
	Random random = new Random();
	
	public Persona() {
		this.confiabilidad = random.nextInt(max + min) + min;
		this.poseeGalleta = true;
	}

	public void darGalleta(){
		setPoseeGalleta(false);
		System.out.println("Se ha dado la galleta al perro.");
	}

	public int getConfiabilidad() {
		return confiabilidad;
	}

	public void setConfiabilidad(int confiabilidad) {
		this.confiabilidad = confiabilidad;
	}
	
	public boolean isPoseeGalleta() {
		return poseeGalleta;
	}
	
	public void setPoseeGalleta(boolean poseeGalleta) {
		this.poseeGalleta = poseeGalleta;
	}
	
}
