import java.util.Scanner;

public class main {
	public static void main(String[] args) {
		Menu();
		Scanner sc = new Scanner(System.in);
		
		//Creacion de instancias
		Persona persona = new Persona();
		Perro perro = new Perro();
		
		
		
		
		int valorMenu = sc.nextInt();
		while(valorMenu != 5){
			if(valorMenu == 1) {
				persona = new Persona();
				System.out.println("---------");
				System.out.println("Persona:");
				System.out.println("- Confiabilidad: " + persona.getConfiabilidad());
				System.out.println("- Posee Galleta: " + persona.isPoseeGalleta());
				System.out.println("---------");
				Menu();
				valorMenu = sc.nextInt();
			}else if(valorMenu == 2) {
				perro = new Perro();
				System.out.println("---------");
				System.out.println("Perro:");
				System.out.println("- Estado de Ànimo: " + perro.getEstadoAnimo());
				System.out.println("- Umbral: " + perro.getUmbral());
				System.out.println("---------");
				Menu();
				valorMenu = sc.nextInt();
			}else if(valorMenu == 3) {
				if(persona.isPoseeGalleta()) {
					persona.darGalleta();
					System.out.println("---------");
					Menu();
					valorMenu = sc.nextInt();
				}else {
					System.out.println("¡Ya no tengo galleta!");
					System.out.println("---------");
					Menu();
					valorMenu = sc.nextInt();
				}
			}else if(valorMenu == 4){
				if(perro.psican(persona) < perro.getUmbral()) {
					perro.morder();
					System.out.println("---------");
					Menu();
					valorMenu = sc.nextInt();
				}else if(perro.psican(persona) < 0 && perro.psican(persona) >= -20) {
					perro.ladrar();
					System.out.println("---------");
					Menu();
					valorMenu = sc.nextInt();
				}else if(perro.psican(persona) > 0) {
					perro.moverCola();
					System.out.println("---------");
					Menu();
					valorMenu = sc.nextInt();
				}
			}
		}
	}
	public static void Menu() {
		System.out.println("Por favor ingrese alguna de las siguientes opciones:");
		System.out.println("");
		System.out.println("1. Nueva Persona");
		System.out.println("2. Nuevo Perro");
		System.out.println("3. Sacar galleta");
		System.out.println("4. Interactuar perro");
		System.out.println("5. Salir");
	}
}
